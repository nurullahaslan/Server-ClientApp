<?php
    $response = json_decode(file_get_contents('php://input'), true);
    $fp = fopen('results.json', 'w');
    fwrite($fp, json_encode($response));
    fclose($fp);
?>