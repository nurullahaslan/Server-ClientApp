<?php
header("Content-Type:application/json");
if (isset($_GET['get']) && $_GET['get']!="") {
$get = $_GET['get'];
 
$string = file_get_contents("results.json");
$json_a = json_decode($string, true);
echo $json_a[$get];
 
}

?>