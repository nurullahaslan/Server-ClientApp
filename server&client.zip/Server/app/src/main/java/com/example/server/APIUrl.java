package com.example.server;

public class APIUrl {
    public static final String BASE_URL = "https://reqres.in/";
}
